/*
 * File:   main.c
 * Author: microdigisoft.com
 *
 * Created on 14 Jan 2021
 */

#include "ADC.h"
#include "config.h"
int cycle_time ;
int count; //count gets incremented for every timer overlap
int ADC_Data;
void main()
{    
 /***************I/O PORT Initialization*************/
  TRISB = 0x00; //RB0 used as Servo signal pin
  TRISA = 0xFF; //Analog inputs 
 //*************************************************//

 ADC_Init(); //Initializes ADC Module
  
    OPTION_REG = 0b00000100;  // Timer0 with external freq and 32 as prescaler
    TMR0=251;       // Load the time value for 1us delayValue can be between 0-256 only
    TMR0IE=1;       //Enable timer interrupt bit in PIE1 register
    GIE=1;          //Enable Global Interrupt
    PEIE=1;         //Enable the Peripheral Interrupt

    while(1)
    { 
        ADC_Data = (ADC_Read(4))*0.039;
        cycle_time = (170-ADC_Data);
    }
}

void interrupt timer_isr()
{  
    if(TMR0IF==1) // Timer has overflown
    {
        TMR0 = 252;     /*Load the timer Value, (Note: Timervalue is 101 instead of 100 as the
                         TImer0 needs two instruction Cycles to start incrementing TMR0 */
        TMR0IF=0;       // Clear timer interrupt flag
        count++;
    } 
    
    if (count >= cycle_time)
    {
        RB0=1;  // complement the value for blinking the LEDs
    }
    
    if (count >= (cycle_time+(200-cycle_time)))
    {
        RB0=0;
        count=0;
    }
}