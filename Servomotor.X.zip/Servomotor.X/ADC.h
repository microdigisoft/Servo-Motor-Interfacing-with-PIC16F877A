/* File: ADC.h */

void ADC_Init();
unsigned int ADC_Read(unsigned char channel);